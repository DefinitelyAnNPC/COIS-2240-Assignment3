public interface Rentable {
    void rentVehicle();
    void returnVehicle();
}